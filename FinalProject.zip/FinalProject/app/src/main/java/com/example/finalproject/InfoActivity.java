package com.example.finalproject;

import android.Manifest;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.TimePickerDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.activity.EdgeToEdge;
import androidx.annotation.RequiresPermission;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.UUID;

public class InfoActivity extends AppCompatActivity {
    Button btFinish;
    EditText etName;
    Button btDate;
    Button btTime;
    TextView tvPreview;
    Button btDelete;

    SimpleDateFormat dateFormat;

    Calendar calendar;

    int reminderPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_info);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        reminderPosition = getIntent().getIntExtra("position", -1);

        btFinish = findViewById(R.id.btSave);
        etName = findViewById(R.id.etName2);
        btDate = findViewById(R.id.btDate2);
        btTime = findViewById(R.id.btTime2);
        tvPreview = findViewById(R.id.tvPreview2);
        btDelete = findViewById(R.id.btDelete);

        dateFormat = new SimpleDateFormat("HH:mm aaa  MM/dd/yyyy", Locale.getDefault());

        String name = getIntent().getStringExtra("name");
        String date = getIntent().getStringExtra("date");

        etName.setText(name);
        tvPreview.setText(date);

        calendar = Calendar.getInstance();

        btDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new DatePickerDialog(InfoActivity.this, d,
                        calendar.get(Calendar.YEAR),
                        calendar.get(Calendar.MONTH),
                        calendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        btTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new TimePickerDialog(InfoActivity.this, t,
                        calendar.get(android.icu.util.Calendar.HOUR_OF_DAY),
                        calendar.get(android.icu.util.Calendar.MINUTE), false).show();
            }
        });

        btFinish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String date = dateFormat.format(calendar.getTime());

                Intent result = new Intent();
                result.putExtra("name", name);
                result.putExtra("date", date);
                result.putExtra("timeInMillis", calendar.getTimeInMillis());
                result.putExtra("position", reminderPosition);
                setResult(InfoActivity.RESULT_OK, result);

                finish();
            }
        });

        btDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(InfoActivity.this);
                builder.setMessage("Are you sure you want to delete this reminder?");

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent result = new Intent();
                        result.putExtra("position", reminderPosition);
                        result.putExtra("delete", true);
                        setResult(InfoActivity.RESULT_OK, result);

                        finish();
                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                builder.show();
            }
        });
    }

    DatePickerDialog.OnDateSetListener d = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
            calendar.set(Calendar.YEAR, year);
            calendar.set(Calendar.MONTH, month);
            calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
            tvPreview.setText("A reminder will be set for " + dateFormat.format(calendar.getTime()));
            tvPreview.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            ));
        }
    };

    TimePickerDialog.OnTimeSetListener t = new TimePickerDialog.OnTimeSetListener() {
        @Override
        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
            calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
            calendar.set(Calendar.MINUTE, minute);
            tvPreview.setText("A reminder will be set for " + dateFormat.format(calendar.getTime()));
            tvPreview.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            ));
        }
    };
}