package com.example.finalproject;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.service.settings.preferences.SettingsPreferenceMetadata;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    SharedPreferences sharedPreferences;

    ArrayList<LinearLayout> reminders = new ArrayList<>();

    Button btAdd;
    ScrollView reminderScroll;
    LinearLayout scrollLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btAdd = findViewById(R.id.btAdd);
        scrollLayout = findViewById(R.id.scrollLayout);
        reminderScroll = findViewById(R.id.reminderScroll);

        SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm aaa  MM/dd/yyyy", Locale.getDefault());

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        for (Map.Entry<String, ?> entry: sharedPreferences.getAll().entrySet()) {
            String name = entry.getKey();
            long timeInMillis = (long) entry.getValue();
            addReminder(name, dateFormat.format(new Date(timeInMillis)), timeInMillis);
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createNotificationChannel();
        }

        btAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (canScheduleExactAlarms(MainActivity.this)) {
                    if (checkNotificationPermissions(MainActivity.this)) {
                        activityReminderLauncher.launch(new Intent(MainActivity.this, CreateReminder.class));
                    }
                }
                else {
                    requestAlarmPermission();
                }
            }
        });
    }

    ActivityResultLauncher<Intent> alarmPermissionLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (!canScheduleExactAlarms(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "Permission to set alarms is required to use this app.", Toast.LENGTH_LONG).show();
                }
            }
    );

    public void requestAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (!canScheduleExactAlarms(this)) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                intent.setData(Uri.fromParts("package", getPackageName(), null));
                alarmPermissionLauncher.launch(intent);
            }
        }
    }

    private boolean canScheduleExactAlarms(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            return alarmManager.canScheduleExactAlarms();
        }

        return true;
    }

    private boolean checkNotificationPermissions(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

            if (!notificationManager.areNotificationsEnabled()) {
                Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                intent.putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName());
                context.startActivity(intent);

                return false;
            }
        }
        else {
            if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) {
                Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                intent.putExtra(Settings.EXTRA_APP_PACKAGE, context.getPackageName());
                context.startActivity(intent);

                return false;
            }
        }
        return true;
    }

    private final ActivityResultLauncher<Intent> activityReminderLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult o) {
                    if (o.getResultCode() == MainActivity.RESULT_OK) {
                        Intent data = o.getData();

                        String name = "";
                        String date = "";
                        long timeInMillis;

                        try {
                            name = data.getStringExtra("name");
                            date = data.getStringExtra("date");
                            timeInMillis = data.getLongExtra("timeInMillis", 0);
                            addReminder(name, date, timeInMillis);

                            scheduleNotification(name, timeInMillis);
                        } catch (NullPointerException npe) {
                            Toast.makeText(MainActivity.this, "No reminder was created", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }
    );

    private final ActivityResultLauncher<Intent> activityInfoLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult o) {
                    if (o.getResultCode() == MainActivity.RESULT_OK) {
                        Intent data = o.getData();
                        int position = data.getIntExtra("position", -1);
                        String name = data.getStringExtra("name");
                        String date = data.getStringExtra("date");

                        boolean delete = false;

                        try {
                            if (position < 0) {
                                throw new NullPointerException();
                            }
                            else {
                                LinearLayout selectedReminder = reminders.get(position);

                                delete = data.getBooleanExtra("delete", false);

                                if (delete) {
                                    scrollLayout.removeView(selectedReminder);
                                    reminders.remove(position);
                                    cancelNotification(name);

                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.remove(name);
                                    editor.apply();
                                }
                                else {
                                    TextView nameV = (TextView) selectedReminder.getChildAt(0);
                                    TextView dateV = (TextView) selectedReminder.getChildAt(1);

                                    nameV.setText(name);
                                    dateV.setText(date);
                                }
                            }
                        } catch (NullPointerException npe) {
                            Toast.makeText(MainActivity.this, "Reminder was not changed", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }
    );

    private void addReminder(String reminder, String date, long timeInMillis) {
        LinearLayout reminderLayout = new LinearLayout(MainActivity.this);
        reminderLayout.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        reminderLayout.setOrientation(LinearLayout.VERTICAL);
        reminderLayout.setBackground(getDrawable(R.drawable.list_background));

        ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) reminderLayout.getLayoutParams();
        params.setMargins(8, 8, 8, 8);
        reminderLayout.setLayoutParams(params);

        TextView reminderTitle = new TextView(MainActivity.this);
        reminderTitle.setTextSize(20);
        reminderTitle.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                reminderTitle.getLineHeight() * 2
        ));
        reminderTitle.setText(reminder);
        reminderLayout.addView(reminderTitle);

        TextView reminderDate = new TextView(MainActivity.this);
        reminderDate.setTextAlignment(TextView.TEXT_ALIGNMENT_TEXT_END);
        reminderDate.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        reminderDate.setText(date);
        reminderLayout.addView(reminderDate);

        scrollLayout.addView(reminderLayout);

        reminders.add(reminderLayout);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putLong(reminder, timeInMillis);
        editor.apply();

        setReminderListener(reminderLayout, reminder, date, reminders.size() - 1);
    }

    private void setReminderListener(LinearLayout reminder, String name, String date, int position) {
        reminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, InfoActivity.class);
                intent.putExtra("name", name);
                intent.putExtra("date", date);
                intent.putExtra("position", position);

                activityInfoLauncher.launch(intent);
            }
        });
    }

    @SuppressLint("ScheduleExactAlarm")
    private void scheduleNotification(String message, long timeInMillis) {
        Intent intent = new Intent(MainActivity.this, Notification.class);
        intent.putExtra("title", message);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                MainActivity.this,
                123,
                intent,
                PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                timeInMillis,
                pendingIntent
        );
    }

    private void cancelNotification(String message) {
        Intent intent = new Intent(MainActivity.this, Notification.class);
        intent.putExtra("title", message);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                MainActivity.this,
                123,
                intent,
                PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.cancel(pendingIntent);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel("REMINDERS", "Reminders", NotificationManager.IMPORTANCE_DEFAULT);

        NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        notificationManager.createNotificationChannel(channel);
    }
}