package com.example.finalproject;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

public class Notification extends BroadcastReceiver {
    private final int id = 123;
    private final String channelID = "REMINDERS";

    public Notification() {
        super();
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String message = intent.getStringExtra("title");

        NotificationCompat.Builder notification = new NotificationCompat.Builder(context, channelID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(message);

        NotificationManager manager = (NotificationManager) context.getSystemService((Context.NOTIFICATION_SERVICE));
        manager.notify(id, notification.build());
    }
}
